# Assignment 3 — Load Simulation, Bottleneck Analysis, and Proposed Fix

## Workload objective

The exam requirement is **3,000 students starting within five minutes**, or approximately **10 exam starts/second** on average. This is not the same as total HTTP request throughput, because each student may generate several requests.

## Simulation method and observed results

AWS Architecture Lab request simulations were performed using the revised architecture and `GET /api/exams/current`.

| Simulator setting | Observed HTTP status | Modeled request duration | Trace |
|---|---|---|---|
| 1 req/s | 200 | 134 ms | 9/9 steps |
| 10 req/s | 200 | 134 ms | 9/9 steps |
| 100 req/s | 200 | 134 ms | 9/9 steps |
| 10× spike | 200 | 134 ms | 9/9 steps |
| 100× spike | 200 | 134 ms | 9/9 steps |

The settings were **simulator inputs**, not independently measured sustained requests per second. The identical response durations mean that the simulation did not show performance degradation or demonstrate 3,000 successful exam starts in five minutes.

![Low-load simulation](../../evidence/load-tests/01-low-load.png)

*Low-load simulation.*
![High-load simulation](../../evidence/load-tests/02-high-load.png)

*High-load simulation.*
![Spike-load simulation](../../evidence/load-tests/03-spike-load.png)

*Spike-load simulation.*

## Architecture Analysis: potential bottleneck

The Architecture Analysis identified **database connection and throughput contention**, with multiple compute components accessing the RDS database without a dedicated proxy/cache layer. This is a **predicted risk**, not a bottleneck measured by CPU, connection count, queue length, p95 latency, or errors.

![Architecture Analysis: predicted database contention](../../evidence/load-tests/database-bottleneck.png)

*Architecture Analysis: predicted database contention.*

### Proposed mitigation — not deployed

Consider application-side PostgreSQL connection pooling, query/index optimization, or **RDS Proxy** if connection spikes warrant its additional expense. Recheck costs, application connection limits, and security. A genuine fix/retest would require the same workload before and after deployment with measured throughput, errors, p95, and RDS/ALB/EC2 metrics.

**Fix applied:** None.  
**Measured before/after improvement:** Not available.  
**CloudWatch load-test evidence:** Not collected.  
**Peak-load requirement verified:** No.

## Architecture analysis and configuration risks

![Simulator architecture analysis scores](../../evidence/load-tests/analysis-scores.png)

*Simulator architecture analysis scores.*
![Simulator single-point-of-failure warning](../../evidence/load-tests/single-point-of-failure.png)

*Simulator single-point-of-failure warning.*
![Simulator configuration findings](../../evidence/load-tests/configuration-issues.png)

*Simulator configuration findings.*

The simulator reported Availability **100%**, Resilience **45%**, Fault Tolerance **100%**, Scalability **80%**, and Security & Isolation **85%**. Its RDS standby warning did not align with the successful simulated RDS failover. Other findings concerned missing or mismatched networking, message-flow, IAM, and HTTPS connections. These should be reviewed before deployment.

## Two additional reasoned scenarios

### Concurrent autosave surge
Thousands of students may save answers together. **Expected risk:** elevated RDS connections, write latency, or failed saves. **Proposed mitigation:** bounded connection pools, indexed writes, safe retry/idempotency, and durable acknowledgements. Test autosave against the five-minute RPO objective. **Not measured.**

### Submission and marking surge
Simultaneous submissions may increase SQS queue depth and marking delay. **Expected risk:** worker backlog and delayed result processing. **Proposed mitigation:** SQS buffering, worker scaling, DLQ, retries, and idempotent processing. **Not measured.**

## Conclusion

The screenshots support **simulated successful request routing at several configured load levels** and a **predicted database contention risk**. They do not satisfy the rubric's strongest requirement of a **CloudWatch-proven bottleneck, applied fix, and equivalent retest**. The platform's actual peak-load capacity remains unverified.